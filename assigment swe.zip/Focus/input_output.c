//
// Created by Lili on 26/03/2020.
//

//
// Created by Lili on 24/03/2020.
//

#include <stdio.h>
#include "input_output.h"

/* FUnction to print the board:
 * Invalid Squares are printed as | - |
 * Valid empty squares are printed as |   |
 * Valid squares with a GREEN piece are printed as | G |
 * Valid squares with a RED piece are printed as | R | */

void print_board(square board[BOARD_SIZE][BOARD_SIZE]){
    printf("****** The Board ******\n");
    printf("      1   2   3   4   5   6   7   8\n");
    for(int i = 0; i < BOARD_SIZE; i ++){
        printf("%d   ", i + 1);
        for (int j = 0; j < BOARD_SIZE; j++){
            if(board[i][j].type == VALID) {
                if(board[i][j].stack == NULL)
                    printf("|   ");
                else{
                    if (board[i][j].stack->p_color == GREEN)
                        printf("| G ");
                    else printf("| R ");
                }
            }
            else
                printf("| - ");
        }
        printf("|\n");
    }
}

// gets coordinates from user where to move on board
char* get_cooridnates(char * msg,square board[BOARD_SIZE][BOARD_SIZE]) {
    char* coordinates = "";
    do {
        printf(msg);
        scanf("%s", coordinates);
        if (strlen(coordinates) != 2) {
            printf("Invalid coordinates.Must be two digits first representing row second column.\n");
        }
        else if (strlen(coordinates) == 2) {
            int row = (int)coordinates[0] -49;
            if (row < 0 || row >7) {
                printf("Invalid row number must be between 1 and 8.\n");
                continue;
            }
            int column = (int)coordinates[1]-49;
            if (column < 0 || column >7) {
                printf("Invalid column number must be between 1 and 8.\n");
                continue;
            }
            if (board[row][column].type == INVALID) {
                printf("selected coordinate is an invalid coordinate.\n");
                continue;
            }
            else {
                break;
            }
        }
    } while (1);
    return coordinates;
}

char get_choice() {
    char choice = ' ';
    do {
        printf("you have reserve pieces do you want to use one of them.\n");
        scanf("%c", &choice);
        if (choice == 'Y' || choice == 'y' || choice == 'N' || choice == 'n') {
            break;
        }
        else {
            printf("invalid choice valid choices are [Y,N].\n");
        }
    } while (1);
}

// uses a reserve piece.
void use_piece(int nextX, int nextY, player* currPlayer, square board[BOARD_SIZE][BOARD_SIZE]) {
    if (board[nextX][nextY].num_pieces < 5) {
        piece* reservePiece = malloc(sizeof(piece));
        reservePiece->next = NULL;
        reservePiece->p_color = currPlayer->player_color;
        piece* temp = reservePiece;
        int count = 0;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        piece* tempOther = board[nextX][nextY].stack;
        while (count < 5 && tempOther != NULL) {
            temp->next = tempOther;
            tempOther = tempOther->next;
            count++;
        }
        piece* previous = tempOther;
        if (tempOther != NULL) {
            while (tempOther != NULL) {
                if (tempOther->p_color == currPlayer->player_color) {
                    currPlayer->piecesreserved++;

                }
                else {
                    currPlayer->enemypieces++;
                }
                previous = tempOther;
                tempOther = tempOther->next;
                free(previous);
            }
        }
        board[nextX][nextY].stack = reservePiece;
        board[nextX][nextY].num_pieces = count;
        board[nextX][nextY].type = VALID;
    }
}

// makes a move given the row and column
void make_move(int currX, int currY, int nextX, int nextY, player* currPlayer, square board[BOARD_SIZE][BOARD_SIZE]) {
    if (board[currX][currY].num_pieces < 5) {
        if (board[nextX][nextY].num_pieces < 5) {
            piece* temp = board[currX][currY].stack;
            int count = board[currX][currY].num_pieces;
            while (temp->next != NULL) {
                temp = temp->next;
            }
            piece* tempOther = board[nextX][nextY].stack;
            while (count <5 && tempOther != NULL) {
                temp->next = tempOther;
                tempOther = tempOther->next;
                count++;
            }
            piece* previous = tempOther;
            if (tempOther != NULL) {
                while (tempOther != NULL) {
                    if (tempOther->p_color == currPlayer->player_color) {
                        currPlayer->piecesreserved++;
                        
                    }
                    else {
                        currPlayer->enemypieces++;
                    }
                    previous = tempOther;
                    tempOther = tempOther->next;
                    free(previous);
                }
            }
            board[nextX][nextY] = board[currX][currY];
            board[nextX][nextY].num_pieces = count;
            board[currX][currY].num_pieces = 0;
            board[currX][currY].stack = NULL;
            board[currX][currY].type = VALID;
        }
            
    }
}

//checks wheter a player has won or not.
int check_winner(player* player, square board[BOARD_SIZE][BOARD_SIZE]) {
    int check = 0;
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++)
        {
            if (board[i][j].type == VALID && board[i][j].stack != NULL &&board[i][j].stack->p_color != player->player_color) {
                check++;
               
            }
                
        }
    }
    return check == 0 && player->piecesreserved == 0 ? 1 : 0;
     
}

// simulate the Domination game
void play_game(player players[PLAYERS_NUM], square board[BOARD_SIZE][BOARD_SIZE]) {
    int turn = 0;
    char * coordinates;
    int currRow = 0, currColumn = 0;
    int nextRow = 0, nextColumn = 0;
    while (1) {
        if (players[turn].piecesreserved > 0 && (get_choice() == 'Y' || get_choice() == 'y')) {
            char* coordinates = "";
            int nextRow = 0, nextColumn = 0;
            do {
                coordinates = get_cooridnates("Enter the piece cooridnate where to move.\n", board);
                nextRow = (int)coordinates[0] - 49;
                nextColumn = (int)coordinates[1] - 49;
                if (board[nextRow][nextColumn].stack->p_color == players[turn].player_color) {
                    printf("cannot move to piece with same color.\n");
                    continue;
                }
                if (board[nextRow][nextColumn].stack == NULL) {
                    break;
                }
                if (board[nextRow][nextColumn].stack->next == NULL) {
                    break;
                }
                else {
                    printf("Cannot do this move please select some other coordinates.\n");
                }
            } while (1);
            use_piece(nextRow, nextColumn, &players[turn], board);
        }
        else {
            printf("Player %s Turn. Your color is %s \n", players[turn].playername, players[turn].player_color == 0 ? "RED" : "GREEN");
            print_board(board);
            do {
                coordinates = get_cooridnates("Enter the current piece coordiantes.\n", board);
                currRow = (int)coordinates[0] - 49;
                currColumn = (int)coordinates[1] - 49;
                if (board[currRow][currColumn].stack->p_color == players[turn].player_color) {
                    break;
                }
                else {
                    printf("can move only %s pieces.\n", players[turn].player_color == 0 ? "RED" : "GREEN");
                    continue;
                }
            } while (1);
            do {
                coordinates = get_cooridnates("Enter the piece cooridnate where to move.\n", board);
                nextRow = (int)coordinates[0] - 49;
                nextColumn = (int)coordinates[1] - 49;
                if (nextRow != currRow || nextColumn != currColumn) {

                    if (board[nextRow][nextColumn].stack->p_color == players[turn].player_color) {
                        printf("cannot move to piece with same color.\n");
                        continue;
                    }
                    if (board[nextRow][nextColumn].stack == NULL) {
                        break;
                    }
                    if (board[nextRow][nextColumn].stack->next == NULL) {
                        break;
                    }
                    else {
                        printf("Cannot do this move please select some other coordinates.\n");
                    }
                }
                else {
                    printf("previous and next coordinates cannot be same.");
                }
            } while (1);
            make_move(currRow, currColumn, nextRow, nextColumn, &players[turn], board);
        }
        turn = turn == 0 ? 1 : 0;
        if (check_winner(&players[turn], board)) {
            turn = turn == 0 ? 1 : 0;
            printf("Player %s won the game.Player color was %S.Player captured %d pieces.",players[turn].playername, players[turn].playername, players[turn].player_color == 0 ? "RED" : "GREEN",players[turn].enemypieces);
            break;
        }
    }
}