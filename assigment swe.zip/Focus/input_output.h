
//
// Created by Lili on 24/03/2020.
//

#ifndef FOCUS_INPUT_OUTPUT_H
#define FOCUS_INPUT_OUTPUT_H

#endif //FOCUS_INPUT_OUTPUT_H

#include "game_init.h"

//Function to print the board
void print_board(square board[BOARD_SIZE][BOARD_SIZE]);
void play_game(player players[PLAYERS_NUM], square board[BOARD_SIZE][BOARD_SIZE]);
int check_winner(player* player, square board[BOARD_SIZE][BOARD_SIZE]);
void make_move(int currX, int currY, int nextX, int nextY, player* currPlayer, square board[BOARD_SIZE][BOARD_SIZE]);
char* get_cooridnates(char* msg, square board[BOARD_SIZE][BOARD_SIZE]);
void use_piece(int nextX, int nextY, player* currPlayer, square board[BOARD_SIZE][BOARD_SIZE]);
